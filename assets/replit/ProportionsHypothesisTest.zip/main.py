# Reference: https://towardsdatascience.com/python-code-from-hypothesis-test-to-online-experiments-with-buiness-cases-e0597c6d1ec
# Reference: https://towardsdatascience.com/the-math-behind-a-b-testing-with-example-code-part-1-of-2-7be752e1d06f

from statsmodels.stats.proportion import proportions_ztest
import scipy.stats as scs
import numpy as np
import matplotlib.pyplot as plt

# Collect Data: try running with 35/50 in Group A, and with 5/50 in Group A
trials = np.array([50, 25]) # ran 50 control group A trials, 25 test group B trials
successes = np.array([35, 20]) # 35/50 A group trials successful, 20/25 in group B

# Are these proportions from two different distributions?  In other words, are groups A and B significantly different from one another in either direction?  If p > 0.05, reject the H0 null that group A and B observations are different distributions
z, p = proportions_ztest(successes, trials, alternative='two-sided')
print("Z: {}, p: {}".format(z, p))

# Compute Metrics for Plotting as a Binomial Distribution and as a Normal Distribution based on the normalized standard deviation of the binomial distribution (which takes into account the number of trials and the probability of observed success)
successes_A = successes[0]
successes_B = successes[1]
trials_A = trials[0]
trials_B = trials[1]
p_A = successes_A / trials_A
p_B = successes_B / trials_B
SE_A = np.sqrt(p_A * (1-p_A)) / np.sqrt(trials_A) # standard error 
SE_B = np.sqrt(p_B * (1-p_B)) / np.sqrt(trials_B) # standard error
num_bins = 100

# Plot Binomial Histogram for Bernouli Outcomes
fig, ax = plt.subplots(figsize=(12,6))
xA = np.linspace(successes_A-49, successes_A+50, num_bins)
yA = scs.binom(trials_A, p_A).pmf(xA)
ax.bar(xA, yA, alpha=0.5, label="Group A")
xB = np.linspace(successes_B-49, successes_B+50, num_bins)
yB = scs.binom(trials_B, p_B).pmf(xB)
ax.bar(xB, yB, alpha=0.5, label="Group B")
plt.xlabel('successes')
plt.ylabel('probability')
plt.legend()
plt.show()
plt.close('all')

# Plot Normalized Distribution
fig, ax = plt.subplots(figsize=(12,6))
x = np.linspace(0, 1, num_bins) # 0% to 100%
yA = scs.norm(p_A, SE_A).pdf(x)
ax.plot(x, yA, label="Group A PDF")
ax.axvline(x=p_A, c='red', alpha=0.5, linestyle='--', label="Group A Observed Success Probability")
yB = scs.norm(p_B, SE_B).pdf(x)
ax.plot(x, yB, label="Group B PDF")
ax.axvline(x=p_B, c='blue', alpha=0.5, linestyle='--', label="Group B Observed Success Probability")
plt.xlabel('Success Proportion')
plt.ylabel('PDF')
plt.legend()
plt.show()
plt.close('all')