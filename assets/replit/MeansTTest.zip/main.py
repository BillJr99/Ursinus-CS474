# Reference: https://towardsdatascience.com/python-code-from-hypothesis-test-to-online-experiments-with-buiness-cases-e0597c6d1ec

from scipy.stats import ttest_ind
from numpy.random import normal
import matplotlib.pyplot as plt
import numpy as np

# Collect Data: try running with normal(60, 10, 100) and (20, 5, 100), and then with the same normal(60, 10, 100) samples for both
control_times = [32, 64, 29, 18, 28, 19, 14, 36, 53, 49, 39] # how long group A took to complete the task, i.e. normal(60, 10, 100)
test_times = [18, 19, 23, 16, 12, 18, 13, 15, 16, 19] # how long group B took to complete the task, i.e. normal(20, 5, 100)

# Do these samples come from two different distributions?  Are the control group times significantly different from the test group times?  If p > 0.05, reject the H0 null that control and test times are from different distributions
t, p = ttest_ind(control_times, test_times)
print("T: {}, p: {}".format(t, p))

# Plot Histogram
bins = np.linspace(0, max(max(control_times), max(test_times)), 10)
plt.hist(control_times, bins=bins, alpha=0.5, label="Control Times")
plt.hist(test_times, bins=bins, alpha=0.5, label="Test Times")
plt.title("Time Histograms Between Test and Control Groups")
plt.legend()
plt.show()
plt.close('all')